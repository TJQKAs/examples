
$(document).ready(function () {
    // var $newdiv;
    // for (var i = 0; i < 100; i++) {
        var fod = "Hello everybody";
        $newdiv = $("<div id='first'></div>");
        $('body').append($newdiv);
        $("#first").html(fod);
    // }
});
